from django.apps import AppConfig


class NoteConfig(AppConfig):
    name = 'note'
