var crashCounter = 0; 
var trees;
var can_drive = true;
/*
oke dus ik had het dus wat code van martijns code pen genakt aleen dat werkte niet lekker met de crashfucntie dus ik heb het opgegeven en heb het maar van de les gejat . 
martijn of lukas mocht je geintreseerd hoever ik ben gekomen met het jatten van de code van martijns code pen: https://github.com/cvanh/leerjaar1-glu/tree/master/periode%202/javascript/opdracht%202


miniz zelf reflectie: jezus wat klink ik als een egoistishe lul ^^ like zoveel heb ik ook niet gedaan. klein beetje de duality of man: https://www.youtube.com/watch?v=KMEViYvojtY
*/

for(let index =0; index < 15; index++) { 
     var img = document.createElement('img');
     img.src = 'tree.jpg';
     img.className = 'tree';
     img.style.left = Math.random(80) * 80 + '%';
     img.style.top = Math.random(80) * 80 + '%';
     document.getElementById('container').appendChild(img);
}

var car = document.getElementById('car'); 
car.style.left = 0;
car.style.top = 0;

document.body.onkeydown = function(event) { 
    var e = event.keyCode; 
   if (can_drive == true) {
    switch(e) { 
        case 40: // down 
           car.style.transform = 'rotate(90deg)'
           car.style.top = (parseInt(car.style.top)) + 10 + 'px';
           if(crash() == true) { 
        car.style.top = (parseInt(car.style.top)) - 10 + 'px'; 
           }
        break;
        case 37: // left 
        car.style.transform = 'rotate(180deg)'
        car.style.left = (parseInt(car.style.left)) - 10 + 'px';
        if(crash() == true) { 
            car.style.left = (parseInt(car.style.left)) + 10 + 'px'; 
               }
        break;
        case 39: // right 
        car.style.transform = 'rotate(0deg)'
        car.style.left = (parseInt(car.style.left)) + 15 + 'px';
        if(crash() == true) { 
            car.style.left = (parseInt(car.style.left)) - 10 + 'px'; 
               }
        break;
        case 38: // top
        car.style.transform = 'rotate(-90deg)'
        car.style.top = (parseInt(car.style.top)) - 10 + 'px';
        if(crash() == true) { 
            car.style.top = (parseInt(car.style.top)) + 10 + 'px'; 
               }
        break;
    }
}
}
function crash(){
    trees = document.getElementsByClassName('tree'); 
    var overlap = false; 
    for(let index = 0; index < trees.length; index++) { 
       overlap = !(car.getBoundingClientRect().right < trees[index].getBoundingClientRect().left ||
                   car.getBoundingClientRect().left > trees[index].getBoundingClientRect().right || 
                   car.getBoundingClientRect().bottom < trees[index].getBoundingClientRect().top ||
                   car.getBoundingClientRect().top > trees[index].getBoundingClientRect().bottom); 
             if(overlap) { 
                crashCounter++;
                document.getElementById("crashcounter").innerHTML = crashCounter;
                car.src = "car_schade.png";
                if (crashCounter <= 50) {
                    can_drive = false;
                }
                return true; 
             }                        
    }
    return overlap;
}
// AABB collision detection